- npm init
- npm install express cors morgan uuid
- npm install --save-dev nodemon
- npm start

- curl http://localhost:3000/api/books
- curl "http://localhost:3000/api/books?author=author-001&category=category-001"
- curl http://localhost:3000/api/docs

