const { buildErrorResponse } = require('../utils/response');

function notFoundHandler(req, res, next) {
  res.status(404).json(
    buildErrorResponse('Not Found', 'NOT_FOUND', `Route ${req.method} ${req.originalUrl} not found`)
  );
}

function errorHandler(err, req, res, next) { // eslint-disable-line no-unused-vars
  console.error(err);
  const status = err.status || 500;
  const code = err.code || (status === 400 ? 'BAD_REQUEST' : status === 404 ? 'NOT_FOUND' : 'INTERNAL_SERVER_ERROR');
  const message = err.message || 'Internal Server Error';
  res.status(status).json(buildErrorResponse(message, code, err.details));
}

module.exports = { notFoundHandler, errorHandler };