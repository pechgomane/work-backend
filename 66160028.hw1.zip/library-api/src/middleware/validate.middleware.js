function validateBody(requiredFields) {
  return (req, res, next) => {
    const missing = requiredFields.filter((f) => {
      const v = req.body[f];
      return v === undefined || v === null || (typeof v === 'string' && v.trim() === '');
    });

    if (missing.length) {
      const err = new Error(`Missing required fields: ${missing.join(', ')}`);
      err.status = 400;
      err.code = 'VALIDATION_ERROR';
      err.details = { missing };
      return next(err);
    }

    next();
  };
}

module.exports = { validateBody };