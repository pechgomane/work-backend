const Categories = require('../models/category.model');
const { buildSuccessResponse } = require('../utils/response');

async function getAll(req, res, next) {
  try {
    const data = await Categories.getAll();
    res.json(buildSuccessResponse('Categories retrieved successfully', data));
  } catch (e) { next(e); }
}

async function getById(req, res, next) {
  try {
    const item = await Categories.getById(req.params.id);
    if (!item) {
      const err = new Error('Category not found');
      err.status = 404; err.code = 'NOT_FOUND'; err.details = `Category with ID '${req.params.id}' does not exist`;
      throw err;
    }
    res.json(buildSuccessResponse('Category retrieved successfully', item));
  } catch (e) { next(e); }
}

async function create(req, res, next) {
  try {
    const created = await Categories.create(req.body);
    res.status(201).json(buildSuccessResponse('Category created successfully', created));
  } catch (e) { next(e); }
}

async function update(req, res, next) {
  try {
    const updated = await Categories.update(req.params.id, req.body);
    if (!updated) {
      const err = new Error('Category not found');
      err.status = 404; err.code = 'NOT_FOUND'; err.details = `Category with ID '${req.params.id}' does not exist`;
      throw err;
    }
    res.json(buildSuccessResponse('Category updated successfully', updated));
  } catch (e) { next(e); }
}

async function remove(req, res, next) {
  try {
    const ok = await Categories.delete(req.params.id);
    if (!ok) {
      const err = new Error('Category not found');
      err.status = 404; err.code = 'NOT_FOUND'; err.details = `Category with ID '${req.params.id}' does not exist`;
      throw err;
    }
    res.json(buildSuccessResponse('Category deleted successfully', { id: req.params.id }));
  } catch (e) { next(e); }
}

module.exports = { getAll, getById, create, update, remove };