const Authors = require('../models/author.model');
const { buildSuccessResponse } = require('../utils/response');

async function getAll(req, res, next) {
  try {
    const data = await Authors.getAll();
    res.json(buildSuccessResponse('Authors retrieved successfully', data));
  } catch (e) { next(e); }
}

async function getById(req, res, next) {
  try {
    const item = await Authors.getById(req.params.id);
    if (!item) {
      const err = new Error('Author not found');
      err.status = 404; err.code = 'NOT_FOUND'; err.details = `Author with ID '${req.params.id}' does not exist`;
      throw err;
    }
    res.json(buildSuccessResponse('Author retrieved successfully', item));
  } catch (e) { next(e); }
}

async function create(req, res, next) {
  try {
    const created = await Authors.create(req.body);
    res.status(201).json(buildSuccessResponse('Author created successfully', created));
  } catch (e) { next(e); }
}

async function update(req, res, next) {
  try {
    const updated = await Authors.update(req.params.id, req.body);
    if (!updated) {
      const err = new Error('Author not found');
      err.status = 404; err.code = 'NOT_FOUND'; err.details = `Author with ID '${req.params.id}' does not exist`;
      throw err;
    }
    res.json(buildSuccessResponse('Author updated successfully', updated));
  } catch (e) { next(e); }
}

async function remove(req, res, next) {
  try {
    const ok = await Authors.delete(req.params.id);
    if (!ok) {
      const err = new Error('Author not found');
      err.status = 404; err.code = 'NOT_FOUND'; err.details = `Author with ID '${req.params.id}' does not exist`;
      throw err;
    }
    res.json(buildSuccessResponse('Author deleted successfully', { id: req.params.id }));
  } catch (e) { next(e); }
}

module.exports = { getAll, getById, create, update, remove };
