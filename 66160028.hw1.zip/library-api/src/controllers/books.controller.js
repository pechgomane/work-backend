const Books = require('../models/book.model');
const Authors = require('../models/author.model');
const Categories = require('../models/category.model');
const { buildSuccessResponse } = require('../utils/response');

async function getAll(req, res, next) {
  try {
    let data = await Books.getAll();
    const { author, category } = req.query;
    if (author) data = data.filter((b) => b.authorId === author);
    if (category) data = data.filter((b) => b.categoryId === category);
    res.json(buildSuccessResponse('Books retrieved successfully', data));
  } catch (e) {
    next(e);
  }
}

async function getById(req, res, next) {
  try {
    const item = await Books.getById(req.params.id);
    if (!item) {
      const err = new Error('Book not found');
      err.status = 404;
      err.code = 'NOT_FOUND';
      err.details = `Book with ID '${req.params.id}' does not exist`;
      throw err;
    }
    res.json(buildSuccessResponse('Book retrieved successfully', item));
  } catch (e) {
    next(e);
  }
}

async function create(req, res, next) {
  try {
    // ตรวจความสัมพันธ์: authorId & categoryId ต้องมีอยู่จริง
    const { authorId, categoryId } = req.body;
    const [author, category] = await Promise.all([
      Authors.getById(authorId),
      Categories.getById(categoryId)
    ]);
    if (!author) {
      const err = new Error('Invalid authorId');
      err.status = 400; err.code = 'BAD_REQUEST'; err.details = `Author '${authorId}' not found`;
      throw err;
    }
    if (!category) {
      const err = new Error('Invalid categoryId');
      err.status = 400; err.code = 'BAD_REQUEST'; err.details = `Category '${categoryId}' not found`;
      throw err;
    }

    const created = await Books.create(req.body);
    res.status(201).json(buildSuccessResponse('Book created successfully', created));
  } catch (e) {
    next(e);
  }
}

async function update(req, res, next) {
  try {
    if (req.body.authorId) {
      const author = await Authors.getById(req.body.authorId);
      if (!author) {
        const err = new Error('Invalid authorId');
        err.status = 400; err.code = 'BAD_REQUEST'; err.details = `Author '${req.body.authorId}' not found`;
        throw err;
      }
    }
    if (req.body.categoryId) {
      const category = await Categories.getById(req.body.categoryId);
      if (!category) {
        const err = new Error('Invalid categoryId');
        err.status = 400; err.code = 'BAD_REQUEST'; err.details = `Category '${req.body.categoryId}' not found`;
        throw err;
      }
    }

    const updated = await Books.update(req.params.id, req.body);
    if (!updated) {
      const err = new Error('Book not found');
      err.status = 404; err.code = 'NOT_FOUND'; err.details = `Book with ID '${req.params.id}' does not exist`;
      throw err;
    }
    res.json(buildSuccessResponse('Book updated successfully', updated));
  } catch (e) {
    next(e);
  }
}

async function remove(req, res, next) {
  try {
    const ok = await Books.delete(req.params.id);
    if (!ok) {
      const err = new Error('Book not found');
      err.status = 404; err.code = 'NOT_FOUND'; err.details = `Book with ID '${req.params.id}' does not exist`;
      throw err;
    }
    res.json(buildSuccessResponse('Book deleted successfully', { id: req.params.id }));
  } catch (e) {
    next(e);
  }
}

module.exports = { getAll, getById, create, update, remove };