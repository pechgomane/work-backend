const BaseModel = require('./base.model');

class BookModel extends BaseModel {
  constructor() {
    super('books.json', 'book');
  }
}

module.exports = new BookModel();