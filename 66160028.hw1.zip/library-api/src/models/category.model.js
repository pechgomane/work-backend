const BaseModel = require('./base.model');
class CategoryModel extends BaseModel {
  constructor() {
    super('categories.json', 'category');
  }
}
module.exports = new CategoryModel();