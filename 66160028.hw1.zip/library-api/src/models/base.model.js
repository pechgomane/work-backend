const path = require('path');
const { readJSON, writeJSON } = require('../utils/filedb');
const { v4: uuidv4 } = require('uuid');

class BaseModel {
  constructor(filename, idPrefix) {
    this.filePath = path.join(__dirname, '../../data', filename);
    this.idPrefix = idPrefix;
  }

  async getAll() {
    return await readJSON(this.filePath);
  }

  async getById(id) {
    const items = await this.getAll();
    return items.find((i) => i.id === id);
  }

  generateId() {
    return `${this.idPrefix}-${uuidv4()}`;
  }

  async create(data) {
    const items = await this.getAll();
    const now = new Date().toISOString();
    const newItem = { id: this.generateId(), createdAt: now, ...data };
    items.push(newItem);
    await writeJSON(this.filePath, items);
    return newItem;
  }

  async update(id, updates) {
    const items = await this.getAll();
    const idx = items.findIndex((i) => i.id === id);
    if (idx === -1) return null;
    const updated = { ...items[idx], ...updates };
    items[idx] = updated;
    await writeJSON(this.filePath, items);
    return updated;
  }

  async delete(id) {
    const items = await this.getAll();
    const idx = items.findIndex((i) => i.id === id);
    if (idx === -1) return false;
    items.splice(idx, 1);
    await writeJSON(this.filePath, items);
    return true;
  }
}

module.exports = BaseModel;