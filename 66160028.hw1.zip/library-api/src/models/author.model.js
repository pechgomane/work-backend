const BaseModel = require('./base.model');
class AuthorModel extends BaseModel {
  constructor() {
    super('authors.json', 'author');
  }
}
module.exports = new AuthorModel();