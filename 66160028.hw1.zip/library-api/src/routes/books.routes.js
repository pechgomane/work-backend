const express = require('express');
const router = express.Router();
const ctrl = require('../controllers/books.controller');
const { validateBody } = require('../middleware/validate.middleware');

// Bonus: Search & Filter ด้วย ?author=authorId&category=categoryId ที่ ctrl.getAll
router.get('/', ctrl.getAll);
router.get('/:id', ctrl.getById);
router.post('/', validateBody(['title', 'authorId', 'categoryId']), ctrl.create);
router.put('/:id', ctrl.update);
router.delete('/:id', ctrl.remove);

module.exports = router;