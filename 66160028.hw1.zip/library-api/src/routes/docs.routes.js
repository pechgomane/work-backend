const express = require('express');
const router = express.Router();

router.get('/', (req, res) => {
  res.json({
    success: true,
    message: 'Library API docs',
    data: {
      baseUrl: '/api',
      endpoints: {
        books: {
          list:   { method: 'GET',    path: '/api/books' },
          get:    { method: 'GET',    path: '/api/books/:id' },
          create: { method: 'POST',   path: '/api/books' },
          update: { method: 'PUT',    path: '/api/books/:id' },
          delete: { method: 'DELETE', path: '/api/books/:id' },
          search: { method: 'GET',    path: '/api/books?author=authorId&category=categoryId' }
        },
        authors: {
          list:   { method: 'GET',    path: '/api/authors' },
          get:    { method: 'GET',    path: '/api/authors/:id' },
          create: { method: 'POST',   path: '/api/authors' },
          update: { method: 'PUT',    path: '/api/authors/:id' },
          delete: { method: 'DELETE', path: '/api/authors/:id' }
        },
        categories: {
          list:   { method: 'GET',    path: '/api/categories' },
          get:    { method: 'GET',    path: '/api/categories/:id' },
          create: { method: 'POST',   path: '/api/categories' },
          update: { method: 'PUT',    path: '/api/categories/:id' },
          delete: { method: 'DELETE', path: '/api/categories/:id' }
        }
      },
      responseFormat: {
        success: { success: true, message: '...', data: [], count: 0 },
        error:   { success: false, message: '...', error: { code: '...', details: '...' } }
      }
    }
  });
});

module.exports = router;