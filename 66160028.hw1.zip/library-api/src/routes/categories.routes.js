const express = require('express');
const router = express.Router();
const ctrl = require('../controllers/categories.controller');
const { validateBody } = require('../middleware/validate.middleware');

router.get('/', ctrl.getAll);
router.get('/:id', ctrl.getById);
router.post('/', validateBody(['name']), ctrl.create);
router.put('/:id', ctrl.update);
router.delete('/:id', ctrl.remove);

module.exports = router;