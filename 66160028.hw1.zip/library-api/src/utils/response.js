function buildSuccessResponse(message, data) {
  const base = { success: true, message };
  if (Array.isArray(data)) {
    return { ...base, data, count: data.length };
  }
  return { ...base, data };
}

function buildErrorResponse(message, code, details) {
  return {
    success: false,
    message,
    error: { code, details }
  };
}

module.exports = { buildSuccessResponse, buildErrorResponse };