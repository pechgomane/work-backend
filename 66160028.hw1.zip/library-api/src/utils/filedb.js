const fs = require('fs').promises;

async function readJSON(filePath) {
  const raw = await fs.readFile(filePath, 'utf-8').catch((err) => {
    if (err.code === 'ENOENT') return '[]';
    throw err;
  });
  try {
    return JSON.parse(raw);
  } catch (e) {
    const err = new Error(`Invalid JSON in ${filePath}`);
    err.status = 500;
    err.code = 'INVALID_JSON';
    throw err;
  }
}

async function writeJSON(filePath, data) {
  const content = JSON.stringify(data, null, 2);
  await fs.writeFile(filePath, content, 'utf-8');
}

module.exports = { readJSON, writeJSON };