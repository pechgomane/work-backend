const express = require('express');
const cors = require('cors');
const morgan = require('morgan');

const booksRoutes = require('./routes/books.routes');
const authorsRoutes = require('./routes/authors.routes');
const categoriesRoutes = require('./routes/categories.routes');
const docsRoutes = require('./routes/docs.routes');

const { notFoundHandler, errorHandler } = require('./middleware/error.middleware');

const app = express();

// Global middlewares
app.use(cors());
app.use(express.json());
app.use(morgan('dev'));

// Health check
app.get('/', (req, res) => {
  res.json({ success: true, message: 'Library API is running', data: { docs: '/api/docs' } });
});

// Routes
app.use('/api/books', booksRoutes);
app.use('/api/authors', authorsRoutes);
app.use('/api/categories', categoriesRoutes);
app.use('/api/docs', docsRoutes);

// 404 & Error
app.use(notFoundHandler);
app.use(errorHandler);

module.exports = app;